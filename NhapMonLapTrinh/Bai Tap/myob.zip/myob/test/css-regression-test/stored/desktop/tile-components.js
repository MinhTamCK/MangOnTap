casper.
  then(function() {
    phantomcss.screenshot('.panel-default', 'panel-default');
  }).
  then(function() {
    phantomcss.screenshot('.panel-for-csstest', 'panel-for-csstest');
  });

casper.run();
