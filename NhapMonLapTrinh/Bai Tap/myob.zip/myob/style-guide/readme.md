Style-guide
===========
A starting point to be incorporated into the AEM project in due course.

It assumes you have node, bower & gulp installed globally.

Installation
------------

From the style-guide folder:

1. `npm install`
2. `bower install`

Running
-------

To run on localhost:3000, with automatic page reload on file save:
`gulp serve`
