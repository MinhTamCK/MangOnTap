'use strict';

var gulp = require('gulp');

gulp.task('app', ['styles:app', 'scripts:app']);

