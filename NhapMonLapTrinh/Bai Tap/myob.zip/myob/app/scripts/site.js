/**
 * @name Site
 * @description Global variables and functions
 * @version 1.0
 */
var minSmallScreen = 768; // break point small screen
