/**
 *  @name plugin store alert
 *  @description when click close alert then store configuration
 *  @version 1.0
 *  @options
 *    option
 *  @events
 *    event
 *  @methods
 *    init
 *    destroy
 */
;(function($, window, undefined) {
  'use strict';

  var pluginName = 'store-alert';

  /**
   * [storeConfiguration description]
   * @param  {[type]} options [description]
   * @return {[type]}         [description]
   */
  var storeConfiguration = function(options) {
    var cookieName = 'alert-' + options.storeAlert.id;
    var dayNumber = options.storeAlert.numday;
    $.cookie(cookieName, true, {
      expires: dayNumber
    });
  };

  /**
   * [checkHideAlert description]
   * @param  {[type]} options [description]
   * @param  {[type]} element [description]
   * @return {[type]}         [description]
   */
  var checkHideAlert = function(options, element) {
    var cookieName = 'alert-' + options.storeAlert.id;
    if ($.cookie(cookieName)) {
      element.addClass('hidden');
    }
  };

  function Plugin(element, options) {
    this.element = $(element);
    this.options = $.extend({}, $.fn[pluginName].defaults, this.element.data(), options);
    this.init();
  }

  Plugin.prototype = {
    init: function() {
      var that = this,
        el = that.element,
        options = that.options;
      // Check show/hidden alert
      checkHideAlert(options, el);
      // Process click close button
      el.find('.close').on('click', function() {
        storeConfiguration(options);
      });
    },
    destroy: function() {
      // remove events
      // deinitialize
      $.removeData(this.element[0], pluginName);
    }
  };

  $.fn[pluginName] = function(options, params) {
    return this.each(function() {
      var instance = $.data(this, pluginName);
      if (!instance) {
        $.data(this, pluginName, new Plugin(this, options));
      } else if (instance[options]) {
        instance[options](params);
      }
    });
  };

  $.fn[pluginName].defaults = {};

  $(function() {
    $('[data-' + pluginName + ']')[pluginName]();
  });

}(jQuery, window));
