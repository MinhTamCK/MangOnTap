/**
 *  @name plugin select on form
 *  @description when click on button auto select show
 *  @version 1.0
 *  @options
 *    option
 *  @events
 *    event
 *  @methods
 *    init
 *    destroy
 */
;(function($, window, undefined) {
  'use strict';

  var pluginName = 'select-change';

  var checkCompanyValidation = function(data) {
    var $labelCareer = $('label[for="career"]');
    var labelCareerText = $labelCareer.text().replace('*','');
    if (data) {
      // On validation filed company
      $labelCareer.text(labelCareerText+' *');
      $('#career').rules('add', {
        required: true,
        noSpace: true,
        messages: L10n.observationForm.career
      });
    } else {
      // Off validation filed company
      $('#career').rules('remove');
      $labelCareer.text(labelCareerText);
    }
  };

  function Plugin(element, options) {
    this.element = $(element);
    this.options = $.extend({}, $.fn[pluginName].defaults, this.element.data(), options);
    this.init();
  }

  Plugin.prototype = {
    init: function() {
      var that = this,
        el = that.element;
      // Handling change on select tag
      el.on('change', function(event) {
        event.preventDefault();
        var flagValid = $(this).find(':selected').data('valid');
        checkCompanyValidation(flagValid);
      });
    },
    destroy: function() {
      // remove events
      // deinitialize
      $.removeData(this.element[0], pluginName);
    }
  };

  $.fn[pluginName] = function(options, params) {
    return this.each(function() {
      var instance = $.data(this, pluginName);
      if (!instance) {
        $.data(this, pluginName, new Plugin(this, options));
      } else if (instance[options]) {
        instance[options](params);
      }
    });
  };

  $.fn[pluginName].defaults = {};

  $(function() {
    $('[data-' + pluginName + ']')[pluginName]();
  });

}(jQuery, window));
