/**
 *  @name plugin select on form
 *  @description when click on button auto select show
 *  @version 1.0
 *  @options
 *    option
 *  @events
 *    event
 *  @methods
 *    init
 *    destroy
 */
;(function($, window, undefined) {
  'use strict';

  var pluginName = 'select-form';

  var setValueDisplay = function(spanTag,textName)
  {
    if(spanTag.css('display') === 'none')
    {
      spanTag.css('display', 'block');
    }
    spanTag.text(textName);
  };

  function Plugin(element, options) {
    this.element = $(element);
    this.options = $.extend({}, $.fn[pluginName].defaults, this.element.data(), options);
    this.init();
  }

  Plugin.prototype = {
    init: function() {
      var that = this,
        el = that.element,
        selectTag = el.find('select'),
        spanTag = el.find('.select-text');
      // At  select change
      selectTag.on('change', function(event) {
        event.preventDefault();
        var textName = $(this).find(':selected').text();
        setValueDisplay(spanTag,textName);
      });

    },
    destroy: function() {
      // remove events
      // deinitialize
      $.removeData(this.element[0], pluginName);
    }
  };

  $.fn[pluginName] = function(options, params) {
    return this.each(function() {
      var instance = $.data(this, pluginName);
      if (!instance) {
        $.data(this, pluginName, new Plugin(this, options));
      } else if (instance[options]) {
        instance[options](params);
      }
    });
  };

  $.fn[pluginName].defaults = {};

  $(function() {
    $('[data-' + pluginName + ']')[pluginName]();
  });

}(jQuery, window));
